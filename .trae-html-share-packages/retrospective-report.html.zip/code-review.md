# 前端专项代码评审报告 — 抓小球小游戏

> 评审维度（课程版规范）：变量命名、代码可读性、JS 事件机制、事件冒泡、绑定合理性、CSS 冗余、Flex/Grid 布局规范性、可维护性。
> 评审对象：每个任务完成后的代码。**存在必修问题时，修改完善并复验后方可进入下一任务。**

---

## T1 · 项目骨架与 Git 初始化 — 评审报告

**评审文件**：`index.html`、`css/style.css`、`js/game.js`、`.gitignore`
**评审结论**：**通过（0 个必修项，0 个建议修改项，2 条后续约定记录）**

### 1. 逐维度评审

| 维度 | 检查内容 | 结果 |
|---|---|---|
| 命名规范 | 目录名 `css` / `js` 全小写；文件名 `index.html`、`style.css`、`game.js` 语义清晰、无缩写歧义 | 通过 |
| 代码可读性 | 三份文件均有中文注释头，说明职责与后续任务归属；HTML 中标注 T2 待建 DOM 位置 | 通过 |
| JS 事件机制 | T1 无事件绑定，无 `onclick` 内联属性 | 通过（不适用） |
| 事件冒泡 | T1 无事件，无冒泡风险 | 通过（不适用） |
| 绑定合理性 | 无绑定 | 通过（不适用） |
| CSS 冗余 | `style.css` 仅有注释头，无冗余声明、无未使用选择器 | 通过 |
| Flex/Grid 规范性 | T1 未涉及布局，留待 T2 评审 | 通过（不适用） |
| 可维护性 | `js/game.js` 首行 `'use strict'`，启用严格模式，可提前暴露隐式全局变量等隐患 | 通过 |

### 2. HTML 结构专项

| 检查项 | 结论 |
|---|---|
| 声明 `<!DOCTYPE html>` | ✅ 标准模式渲染，避免怪异模式 |
| `<html lang="zh-CN">` | ✅ 语言与页面文案一致，利于阅读器与检索 |
| `<meta charset="UTF-8">` 位于 `<head>` 顶部 | ✅ 在文档前 1024 字节内，避免中文乱码 |
| 样式表置于 `<head>`、脚本置于 `</body>` 前 | ✅ 样式先加载避免 FOUC；脚本在 DOM 就绪后执行，无需 `defer` |
| 无内联 `style` / 内联 `onclick` | ✅ 符合 spec §3「结构、样式、行为分离」约定 |
| 资源引用为相对路径 | ✅ `file://` 协议下可直接打开运行 |

### 3. 必修问题清单

**无。** 无需修改。

（说明：评审未发现变量命名、冗余 CSS、绑定合理性方面的任何问题；T1 不涉及事件与布局，相关维度不适用而非忽略。）

### 4. 后续约定记录（非缺陷，供 T2–T7 遵守）

- **约定 1（脚本位置）**：`<script src="js/game.js">` 保持在 `</body>` 前，**不要**上移到 `<head>`。若必须上移，需加 `defer`，否则 `game.js` 执行时 DOM 尚未解析，`querySelector` 会返回 `null`。
- **约定 2（注释语言）**：代码注释统一使用中文，与课程交付要求一致；后续新增代码不得出现无注释的关键逻辑块。

### 5. 结论

T1 代码骨架干净、链路正确、无技术债，**通过评审**，可进入阶段 5 人工验证。

---

## T2 · 页面结构与视觉基调 — 评审报告

**评审文件**：`index.html`、`css/style.css`、`js/game.js`
**评审结论**：**通过（发现 1 个必修项已修复，2 条设计约束已记录，1 项规格增补已说明）**

### 1. 逐维度评审

| 维度 | 检查内容 | 结果 |
|---|---|---|
| 变量命名 | JS 无业务变量；CSS 采用 BEM 风格（`.hud__item`、`.result-panel__score-value`），命名与层级语义一致，无 `box1`/`div2` 类命名 | 通过 |
| 代码可读性 | HTML 每块结构均有中文注释说明用途；CSS 按「变量 / 重置 / 游戏区 / HUD / 按钮 / 小球 / 遮罩 / 结算 / 工具类」九段分区，段间有分隔注释 | 通过 |
| JS 事件机制 | T2 不涉及事件绑定，HTML 中无内联 `onclick` | 通过（不适用） |
| 事件冒泡 | **主动设计**：`.hud` 与 `.result-panel` 被刻意置于 `.game` 之外，使顶部栏的点击不会冒泡进游戏区，从结构层面满足 spec「点顶部不扣分」，而非依赖 `stopPropagation()` 去修补 | 通过（正向设计） |
| 绑定合理性 | 页面仅 2 个按钮，均使用语义化 `<button type="button">`；未在 T2 提前绑定事件（避免逻辑与结构任务混杂） | 通过 |
| CSS 冗余 | 两个按钮共用 `.btn` 类，避免重复声明按钮样式；逐一核对 11 个类选择器，**无未使用选择器**；无 `float`、无 `!important` | 见必修项 R1 |
| Flex/Grid 布局规范性 | `.hud` 用 Flexbox + `space-between` + `gap` 实现三段分布，未使用绝对定位排版；`.hud__item` 用 `align-items: baseline` 实现标签与数值基线对齐；`.result-panel` 用 Flex 纵向 + `gap` 控制间距。**小球才使用 `position: absolute`**（其坐标由随机数决定，属必要用法） | 通过 |
| 可维护性 | 颜色 / 尺寸 / 阴影全部收敛到 `:root` 变量；`* { box-sizing: border-box }` 统一盒模型，避免后续尺寸计算陷阱 | 通过 |

### 2. 必修问题清单（已修复）

**R1：`html, body` 上的 `height: 100%` 为冗余声明（已删除）**

- **问题**：`.game` 已使用 `height: 100vh` 撑满视口，`body` 高度由内容自然得到视口高度；此时 `height: 100%` 不产生任何实际效果，属于无效声明。
- **修复**：删除该行，保留 `margin: 0` 与 `overflow: hidden`。
- **复验**：`.game` 的高度来源未变（仍为 `100vh`），页面铺满效果不受影响，无滚动条仍成立。

### 3. 规格增补说明（需知悉）

spec §7.2 的变量表列了 8 个变量，实现中**新增 2 个**，原因如下：

| 新增变量 | 值 | 原因 |
|---|---|---|
| `--color-on-primary` | `#ffffff` | 主色按钮上的文字需要白色；若直接写字面色值或借用 `--color-panel`，前者违反「颜色必须用变量」的 NFR-5，后者属于语义错用 |
| `--shadow-panel` | `0 2px 12px rgba(0,0,0,0.08)` | HUD 与结算面板需要阴影，但阴影色不属于 spec 变量表；收敛为一个阴影 token 供两处复用 |

同时，悬停加深色复用了已有的 `--color-ball-hover`，标签文字的弱化通过 `opacity: 0.6` 实现（而非新增灰色变量），以尽量少地扩充变量集。

### 4. 设计约束记录（非缺陷）

- **约束 1（`.is-hidden` 必须置于文件末尾）**：`.result-panel` 使用 `display: flex`，与 `.is-hidden` 的 `display: none` 特异性相同（均为 0,1,0），因此**只能靠书写顺序决定胜负**。已在 CSS 第 9 段加注释标明。这是本方案唯一的顺序敏感点；备选方案是加 `!important`，权衡后选择「顺序 + 注释」，因为本项目样式体量小、可控。
- **约束 2（`dom` 对象暂未被使用）**：`js/game.js` 中的 `dom` 引用集合是 plan.md 中 T2 的明确交付内容，将于 T3 起被全部消费，属计划内的前向声明，非死代码。

### 5. 观察项（不修改，记录留痕）

- 结算面板使用 `<h2>`，页面无 `<h1>`。作为单页游戏界面无 SEO / 文档大纲需求，按 YAGNI 不新增标题元素。
- `.countdown-overlay` 已设置 `pointer-events: none`，在 T2 中该元素处于隐藏态故无实际作用，属于为 T3 预置的防拦截设置。

---

## T3 · 状态机与倒计时 — 评审报告

**评审文件**：`js/game.js`、`css/style.css`、`acceptance-checklist.md`
**评审结论**：**通过（0 个必修项，5 条记录留痕）**

### 1. 逐维度评审

| 维度 | 检查内容 | 结果 |
|---|---|---|
| 变量命名 | 状态枚举 `GAME_STATES`；常量全大写 + 下划线（`GAME_DURATION_MS`、`PRE_COUNTDOWN_SECONDS`、`PRE_COUNTDOWN_INTERVAL_MS`、`TICK_INTERVAL_MS`、`MS_PER_SECOND`）；函数为动词短语（`startGame`、`startPreCountdown`、`showCountdownNumber`、`startPlaying`、`onTick`、`endGame`）；局部变量语义化（`remainingMs`、`remaining`）。无 `a1`/`tmp` 类无意义命名 | 通过 |
| 代码可读性 | 文件按「常量 → 元素引用 → 状态 → 工具函数 → 计时器管理 → 流程控制 → 事件绑定」七段分区，段间有分隔注释；`formatTime` / `updateTimerDisplay` / `showCountdownNumber` 带中文 JSDoc 参数说明；关键非直觉写法（强制回流、时间戳差值）均有行内注释 | 通过 |
| JS 事件机制 | 事件绑定仅 1 处，使用 `addEventListener('click', startGame)` 具名函数引用（便于后续移除/调试，且避免匿名函数无法解绑）；HTML 中无内联 `onclick`；`disabled` 属性的启用/禁用由流程函数统一控制，未依赖 CSS 模拟不可点 | 通过 |
| 事件冒泡 | 本任务未新增冒泡风险：开始按钮位于 `.hud`（在 `.game` **之外**），其点击不会冒泡进游戏区；`.countdown-overlay` 已设 `pointer-events: none`，倒计时期间整屏遮罩不会拦截任何点击，因此 T5 的游戏区委托逻辑不会被遮挡层"吃掉"事件 | 通过 |
| 绑定合理性 | 未在 T3 提前绑定游戏区 `click`、球元素 `click`（那是 T5 的交付内容），也未给 `restartButton` 提前绑定（T6 交付），任务边界清晰，避免"半成品绑定"造成的重复计分隐患 | 通过 |
| CSS 冗余 | 新增 1 条选择器 `.countdown-overlay__number.is-pop` + 1 组 `@keyframes countdown-pop`，均被 JS 实际添加的类名所引用，无未使用选择器；无 `float`、无 `!important`；`.is-hidden` 仍位于样式表末尾，顺序敏感点未被破坏 | 通过 |
| Flex/Grid 布局规范性 | 遮罩延续 `display: flex` + `align-items/justify-content: center` 居中，未引入绝对定位微调；数字动画只用 `transform` + `opacity`，不触发重排，符合 NFR-1 | 通过 |
| 可维护性 | 全部魔法数字常量化（`120000`、`3`、`1000`、`100`、`1000`），无散落字面量；计时采用时间戳差值法（`endTime - Date.now()`）避免 `setInterval` 累积漂移；计时器句柄集中登记到 `timers` 并由 `clearAllTimers()` 统一清理，为 T6「连续重新开始不产生重复计时器」幂等化预留了收口点 | 通过 |

### 2. 必修问题清单

**无。** 本任务未发现需要修改的缺陷。

### 3. 记录留痕（非缺陷，供后续任务知悉）

- **记录 1（`startGame()` 里的 `clearAllTimers()`）**：当前实现只允许从 `IDLE` 启动，而 `IDLE` 下必然没有活动计时器，因此这一句在 T3 内并非必需。保留的理由是 plan.md 中 T6 明确要求 `startGame()` 幂等（`over → countdown` 重开时需清掉上一局残留），此处提前把清理收口到入口处，T6 无需再补。
- **记录 2（预备倒计时的毫秒级漂移）**：`3→2→1` 用 `setInterval(1000ms)` 累加切换，理论上有毫秒级漂移，但总时长仅 3 秒、误差可忽略；而**游戏内的 120 秒计时没有使用累加**，改用 `endTime - Date.now()` 差值法，不存在漂移，这是两处刻意采用不同策略的原因。
- **记录 3（`endGame()` 的范围）**：本任务只做「停表 + 切状态 + 时间钉在 `00:00`」，结算面板与「重新开始」按 plan.md 归属 T6，属计划内的前向声明，不是缺失实现。
- **记录 4（一局结束后按钮仍为 disabled）**：`over` 状态下没有重新开始入口（T6 才加），需 `F5` 刷新才能重测。该行为已写入 T3 验收清单的「本任务的预期行为」段落，避免被误判为失败。
- **记录 5（`void dom.countdownNumber.offsetWidth`）**：`void` 运算符用于显式丢弃回流触发的返回值，是「强制重播 CSS 动画」的标准手法（移除类 → 触发回流 → 重新添加类），已加行内注释说明意图。

### 4. 结论

T3 代码常量收敛、分区清晰、事件绑定最小且无冒泡隐患，时间计算方式符合 NFR-1/NFR-5 要求，**通过评审**，可进入阶段 5 人工验证。

---

## T4 · 小球渲染与安全区随机定位 — 评审报告

**评审文件**：`js/game.js`、`css/style.css`、`acceptance-checklist.md`
**评审结论**：**通过（0 个必修项，1 个建议项已于本任务内改进，4 条记录留痕）**

### 1. 逐维度评审

| 维度 | 检查内容 | 结果 |
|---|---|---|
| 变量命名 | 常量 `BALL_SIZE` / `SAFE_GAP` / `HUD_HEIGHT`（全大写 + 下划线，语义明确）；函数均为动词短语（`getCssPixel` / `getBallSize` / `getSafeBounds` / `getSafePosition` / `spawnBall` / `replaySpawnAnimation` / `constrainBallToSafeArea` / `onWindowResize`）；局部变量 `bounds` / `currentLeft` / `clampedX` 表意清楚，无 `x1` / `temp` 类命名 | 通过 |
| 代码可读性 | 新增函数均带中文 JSDoc（说明目的、参数与返回值）；关键非直觉写法（强制回流、窗口极小时的 `Math.max` 收敛）均有行内注释；文件仍保持「常量 → 元素引用 → 状态 → 工具函数 → 计时器管理 → 流程控制 → 事件绑定」分区结构 | 通过 |
| JS 事件机制 | `window.resize` 使用具名函数 `onWindowResize` 绑定（便于解绑与调试，不写匿名函数）；HTML 无内联 `onclick`；小球元素**未**直接绑定 `click`（按 plan 归属 T5 的委托逻辑，避免在本任务提前埋下"一球两分"隐患） | 通过 |
| 事件冒泡 | 本任务未新增冒泡风险：`resize` 不参与冒泡链；小球的坐标与显隐完全由 JS 直接控制，未借父级事件传递 | 通过 |
| 绑定合理性 | `resize` 只在 `window` 上绑定一次（而非每次开局重复绑定）；`onWindowResize` 内含状态守卫（仅 `PLAYING` 执行重约束），避免 `idle` / `countdown` / `over` 下的无谓计算 | 通过 |
| CSS 冗余 | 新增 `.ball.is-spawn` + `@keyframes ball-pop-in`，均被 JS 实际添加的类名引用，无未使用选择器；复用既有 `--color-ball` / `--ball-size`，未新增重复变量；无 `!important`；`.is-hidden` 仍在文件末尾，顺序敏感点未被破坏 | 通过 |
| Flex/Grid 布局规范性 | 小球延续 `position: absolute` + `left/top`（spec §7.1 明确要求，随机坐标无法用 Flex/Grid 表达）；动画只用 `transform` + `opacity`，不触发重排，符合 NFR-1 | 通过 |
| 可维护性 | 球径 / 边距 / 顶部栏高度**统一以样式表 CSS 变量为唯一来源**（`getCssPixel` 读取 `--ball-size` / `--safe-gap` / `--hud-height`），消除 JS 与 CSS 两处硬编码不一致的风险；边界公式收敛进单一 `getSafeBounds()`，随机定位与窗口重约束共同复用 | 通过 |

### 2. 建议项（已于本任务内改进）

**R2（T4 内改进）：把「尺寸单一来源」原则从球径扩展到边距与顶部栏高度**

- **问题（初版）**：初版仅让 `getBallSize()` 读取 CSS 变量，而 `SAFE_GAP` / `HUD_HEIGHT` 仍以 JS 常量参与坐标计算，与样式表中的 `--safe-gap` / `--hud-height` 形成两处硬编码，存在"改一处忘另一处"的隐患。
- **改进**：抽出通用读取器 `getCssPixel(name, fallback)`，`getSafeBounds()` 改为从样式表同时读取球径、边距、顶部栏高度三者，JS 常量统一降级为「变量缺失时的兜底值」。
- **复验**：`--ball-size` / `--safe-gap` / `--hud-height` 三个变量均存在且可解析，读取结果与常量值一致，安全区计算结果不变。

### 3. 必修问题清单

**无。** 未发现影响功能正确性的缺陷。

### 4. 记录留痕（非缺陷，供后续任务知悉）

- **记录 1（随机来源单一）**：`getSafePosition()` 仅依赖 `Math.random()`，无种子/缓存，因此每次 `spawnBall()` 都独立随机，满足"多次开局位置明显随机"；T5 点中后刷新位置复用同一函数，行为一致。
- **记录 2（`replaySpawnAnimation` 强制回流）**：移除 `is-spawn` → `void offsetWidth` → 重加 `is-spawn`，与 T3 倒计时数字同款的"重播 CSS 动画"手法；省略中间回流会被浏览器合并两次类变更，导致动画不重播，已加注释。
- **记录 3（动画与 hover 的 transform 叠加）**：`.ball:hover` 用 `transform: scale(1.08)`，出现动画也用 `transform`。动画仅 0.18s 且无 `forwards`，结束后 transform 回归基础值，不影响后续 hover 放大；两者时间上几乎不重叠，无需额外处理。
- **记录 4（`resize` 重约束策略）**：窗口变化时采用"就近 clamp"而非"重新随机"，避免玩家缩窗瞬间被"球突然跳走"干扰；clamp 与随机共享 `getSafeBounds()`，未复制公式。

### 5. 结论

T4 边界计算收敛到单一函数、尺寸以样式表为唯一来源、事件绑定最小且带状态守卫，动画性能符合 NFR-1，**通过评审**，可进入阶段 5 人工验证。

---

## T5 · 点击判定与计分 — 评审报告

**评审文件**：`js/game.js`、`acceptance-checklist.md`
**评审结论**：**通过（0 个必修项，0 个建议项，4 条记录留痕）**

### 1. 逐维度评审

| 维度 | 检查内容 | 结果 |
|---|---|---|
| 变量命名 | 常量 `INITIAL_SCORE` / `SCORE_ON_HIT` / `SCORE_ON_MISS`（语义与正负号一目了然）；状态变量 `score` 单一、无歧义；处理函数 `handleGameAreaClick`（区域级）/ `updateScore`（渲染级）职责从命名即可区分；无 `s`/`n` 类简写 | 通过 |
| 代码可读性 | 处理函数带中文 JSDoc（说明委托策略、各分支行为）；命中分支与点空分支各有行内注释点明"为何在此处换位置""为何不移动小球"；文件分区由七段扩展为八段（新增「事件处理」），段间分隔注释一致 | 通过 |
| JS 事件机制 | **事件委托**：`click` 只绑定在 `.game` 上一次，通过 `event.target.closest('.ball')` 判定目标；**小球元素未单独绑定** `click`（否则球的处理与区域冒泡会叠加，造成"一球两分"）；`window.resize` 与开始按钮仍为具名函数绑定 | 通过 |
| 事件冒泡 | 计分天然满足"点顶部不扣分"：`.hud` 与 `.result-panel` 均为 `.game` 之外的兄弟节点，其点击不进入游戏区委托范围；`.countdown-overlay` 的 `pointer-events: none` 使倒计时期间点击穿透到 `.game`，此时由状态守卫兜住、不计分。无 `stopPropagation()` 修补式写法 | 通过 |
| 绑定合理性 | 游戏区 `click` 仅绑定一次（非每次开局重复绑定，避免监听器堆积）；`handleGameAreaClick` 内**先做状态守卫**（仅 `PLAYING` 计分），保证 `idle`/`countdown`/`over` 点击无副作用；未提前为 `restartButton` 绑定（属 T6） | 通过 |
| CSS 冗余 | 本任务**未改动样式表**（分数数值已有等宽数字 `tabular-nums`，无需新增"变化时样式"），无新增选择器、无冗余 | 通过（未涉及） |
| Flex/Grid 布局规范性 | 本任务不涉及布局；顶部 HUD 的三段 Flex 布局沿用 T2，未因新增逻辑而改动 | 通过（未涉及） |
| 可维护性 | 计分数值全部常量化（`2` / `-1` / `0`），无散落字面量；计分入口收敛到单一处理函数，后续 T6 只需在该函数的状态守卫处生效、无需另铺分支；`updateScore()` 与 `updateTimerDisplay()` 形成对称的"渲染工具"命名 | 通过 |

### 2. 必修问题清单

**无。** 未发现影响功能正确性的缺陷。

### 3. 记录留痕（非缺陷，供后续任务知悉）

- **记录 1（为何不绑球自身的 `click`）**：小球位于 `.game` 内部，点击必然冒泡到 `.game`。若同时给球元素绑 `click`，一次点击会被"球的处理 + 区域委托"各计一次 → `+4`。故本任务只用委托一处，球节点不绑定任何事件。
- **记录 2（命中即换位置 ⇒ 连点同一处第二次会扣分）**：命中分支先 `+2` 再 `spawnBall()` 把球移走，因此"快速连点同一坐标"的第二次点击落点已是空白 → 按规则 `-1`。这正是 spec FR-5"同一个球不会被重复计分"的实现方式，属预期行为而非缺陷（验收项 E2 只要求"不出现重复加分"，成立）。
- **记录 3（点空分支不移动小球）**：`SCORE_ON_MISS` 分支只 `updateScore()`，不触碰 `left`/`top`，与 spec FR-5"点空小球保持原位不动"一致。
- **记录 4（顺带的重构：`onWindowResize` 归位）**：T4 时 `onWindowResize` 落在「流程控制」段，本任务将其与 `handleGameAreaClick` 一并收进新的「事件处理」段，使"事件处理"与"流程控制"职责分明；行为零变化，仅分区更清晰。

### 4. 结论

T5 以事件委托实现计分、事件绑定最小且带状态守卫、冒泡隔离靠结构而非补丁，计分常量与渲染函数命名对称，**通过评审**，可进入阶段 5 人工验证。

---

## T6 · 结算面板与重新开始 — 评审报告

**评审文件**：`js/game.js`、`acceptance-checklist.md`、`css/style.css`（复核未改动）
**评审结论**：**通过（0 个必修项，0 个建议项，5 条记录留痕）**

### 1. 逐维度评审

| 维度 | 检查内容 | 结果 |
|---|---|---|
| 变量命名 | 三个新函数命名形成清晰的语义阶梯：`endGame`（本局结束）/ `resetGame`（单局状态复位）/ `restartGame`（用户动作：复位 + 重开）；三者职责由名字即可分辨，无 `doIt` / `handle` 类模糊命名 | 通过 |
| 代码可读性 | 每个函数带中文 JSDoc 说明职责；`endGame()` 内五行各带行内注释，逐条对应 spec FR-8 的"球消失 / 计时停止 / 面板出现"；`restartGame()` 仅两行、编排意图一目了然 | 通过 |
| JS 事件机制 | `restartButton` 使用具名函数 `restartGame` 绑定，与 `startGame` / `handleGameAreaClick` 风格统一；HTML 无内联 `onclick`；面板显隐仍由 JS 通过 `is-hidden` 类切换，未改用内联样式 | 通过 |
| 事件冒泡 | 结算面板位于 `.game` **之外**（与 `.hud` 同级），因此点击「重新开始」不会冒泡进游戏区、不会触发委托的扣分逻辑；面板显示的纯点击也落在游戏区之外，天然不改变分数 | 通过 |
| 绑定合理性 | `restartButton` 只在初始化阶段绑定一次；面板隐藏后按钮不可点（`display: none`），快速连点不会重复触发重开；未新增对球元素的绑定 | 通过 |
| CSS 冗余 | **本任务未改动样式表**：T2 已建成完整的 `.result-panel` 系列样式（白卡 / 圆角 / 阴影 / 标题 / 分数 / 按钮），T6 直接复用，无新增选择器、无冗余声明 | 通过（未涉及） |
| Flex/Grid 布局规范性 | 面板沿用 T2 的 Flex 纵向 + `gap` 布局与 `translate(-50%,-50%)` 居中，本任务未改动布局 | 通过（未涉及） |
| 可维护性 | 「复位」与「重开」职责拆分为两个函数，`restartGame()` = `resetGame()` + `startGame()` 的组合式编排，后续若要"仅复位不重开"可直接复用 `resetGame()`；状态机收口完整：`idle → countdown → playing → over → (restart) → countdown` 全程无旁路 | 通过 |

### 2. 必修问题清单

**无。** 未发现影响功能正确性的缺陷。

### 3. 记录留痕（非缺陷，供后续任务知悉）

- **记录 1（`resetGame()` 把状态设回 `IDLE` 的用意）**：`startGame()` 的状态守卫是 `if (gameState !== GAME_STATES.IDLE) return;`。为复用它而不放宽守卫，`resetGame()` 收尾把状态复位到 `IDLE`，从而 `restartGame()` 能"先复位、再走标准启动流程"，避免为"重开"另写一条平行启动路径（防止两套启动逻辑分叉）。
- **记录 2（`resetGame()` 内保留 `clearAllTimers()`）**：此为 plan.md T6 明确要求项，使 `resetGame()` **自包含**（即便将来被单独调用也能干净复位）；在当前调用路径（`over` 后点重开）中 `endGame()` 已停过表，此处属双保险，不产生副作用。`startGame()` 入口处同样有 `clearAllTimers()`，二者共同保证"多次重新开始不产生重复计时器"（NFR-2）。
- **记录 3（`endGame()` 里对倒计时遮罩的"兜底隐藏"）**：正常流程中遮罩在进入 `playing` 前已隐藏，此处再加一次 `is-hidden` 属防御性写法，成本极低且能覆盖"未来若流程调整导致遮罩未及隐藏"的情形，保证归零瞬间画面干净。
- **记录 4（结算期间顶部按钮仍为不可点态）**：`over` 状态下顶部「开始游戏」按钮保持 `disabled`，重新开始入口集中在面板内。这与 spec §4 状态表完全一致，属设计而非缺陷。
- **记录 5（面板显隐与 `.is-hidden` 的顺序敏感点）**：`.result-panel` 为 `display: flex`，靠 `.is-hidden`（文件末尾、同为 0,1,0 特异性）以书写顺序覆盖。T6 未改动样式表，该约束继续保持成立。

### 4. 结论

T6 补齐了状态机闭环（`over → restart → countdown`），复位与重开职责清晰拆分并复用既有守卫，计时清理双保险满足 NFR-2，**通过评审**，可进入阶段 5 人工验证。

---

## T7 · 总体验收与全量代码评审（收尾） — 评审报告

**评审文件**：`index.html`、`css/style.css`、`js/game.js`（三份源文件**全量**评审，非增量）
**评审结论**：**通过（1 个必修项已修复；5 条观察项记录留痕）**

### 1. 全量逐维度评审

| 维度 | 检查内容 | 结果 |
|---|---|---|
| 变量命名 | JS 常量全大写 + 下划线且语义完整（`GAME_DURATION_MS`、`SCORE_ON_HIT`、`SECONDS_PER_MINUTE`……），函数为动词短语且形成语义阶梯（`startGame` / `endGame` / `resetGame` / `restartGame`、`getSafeBounds` / `getSafePosition` / `spawnBall` / `constrainBallToSafeArea`）；CSS 类名统一 BEM（`.hud__value`、`.result-panel__score-value`）；`dom` 键名与元素 id 一一对应。**全项目无 `a1`/`tmp`/`data2` 类无意义命名** | 通过 |
| 代码可读性 | `game.js` 分「常量 → 元素引用 → 状态 → 工具函数 → 计时器管理 → 流程控制 → 事件处理 → 事件绑定」八段，段间分隔注释齐整；`style.css` 分「变量 → 重置 → 游戏区 → HUD → 按钮 → 小球 → 遮罩 → 结算 → 工具类」九段；每个函数均有中文 JSDoc，非直觉写法（强制回流、时间戳差值、就地约束）均有行内注释 | 通过 |
| JS 事件机制 | 全项目**共 4 处**绑定，全部使用具名函数引用（`startGame` / `handleGameAreaClick` / `restartGame` / `onWindowResize`），无匿名函数、无 `onclick` 内联；游戏区采用**事件委托**（一次绑定 + `closest('.ball')` 判定），球元素不单独绑 `click` | 通过 |
| 事件冒泡 | 「点顶部不扣分」「点面板不扣分」均由**结构保证**（`.hud` / `.result-panel` 是 `.game` 的兄弟节点，事件不进入游戏区委托范围），未使用任何 `stopPropagation()` 补丁；`.countdown-overlay` 的 `pointer-events: none` 使预备期间点击穿透，由状态守卫兜住不计分 | 通过 |
| 绑定合理性 | 4 处绑定均在**初始化阶段一次性**完成，不在开局/重开时重复绑定（无监听器堆积）；`handleGameAreaClick` / `onWindowResize` 入口即做 `PLAYING` 状态守卫；按钮 `disabled` 由流程函数统一控制 | 通过 |
| CSS 冗余 | 逐一核对 **14 个类选择器 + 3 组 `@keyframes`**，全部被 HTML 类名或 JS 动态类名引用，**无未使用选择器**；无 `float`、无 `!important`；按钮样式收敛到共用 `.btn` 类；`.is-hidden` 位于文件末尾，顺序敏感约束保持成立 | 通过 |
| Flex/Grid 布局规范性 | `.hud`（`space-between` + `gap` + `align-items`）、`.hud__item`（`baseline`）、`.result-panel`（纵向 Flex + `gap`）、`.countdown-overlay`（居中 Flex）四处布局全部用 Flexbox 表达，无 `float`、无手写 margin 微调排版；**唯一使用 `position: absolute` 的是小球**（随机坐标属必要用法，符合 spec §7.1） | 通过 |
| 可维护性 | 全部时间/计分/计时参数均为具名常量（见下方「常量清单核对」）；尺寸以样式表变量为唯一来源（`getCssPixel` 统一读取）；副作用入口收敛（`clearAllTimers` 单一清理点、`updateScore`/`updateTimerDisplay` 对称渲染工具） | 见必修项 R3 |

### 2. 必修问题清单（已修复）

**R3：`formatTime()` 中的 `60` 与 `padStart(2)` 补零宽度未具名（已修复）**

- **问题**：`formatTime()` 里 `Math.floor(totalSeconds / 60)`、`totalSeconds % 60` 的 `60`（每分钟秒数）与 `padStart(2, '0')` 的 `2`（mm:ss 字段补零宽度）为散落字面量，与 spec NFR-5「所有魔法数字以具名常量定义」不符。（T3 评审曾笼统表述为「无散落字面量」，此处在 T7 全量复核时修正该表述。）
- **修复**：新增常量 `SECONDS_PER_MINUTE = 60` 与 `TIME_FIELD_WIDTH = 2`，`formatTime()` 改用二者；函数行为与输出字符串完全不变。
- **复验**：`formatTime(120)` → `"02:00"`、`formatTime(59)` → `"00:59"`、`formatTime(0)` → `"00:00"`，与修复前逐值一致。

### 3. 常量清单核对（spec NFR-5）

| JS 常量 | 值 | 对应 CSS 变量 / 说明 |
|---|---|---|
| `GAME_DURATION_MS` | `120000` | spec §5 FR-2 固定 120 秒 |
| `PRE_COUNTDOWN_SECONDS` | `3` | spec §7.3 文案 `3`/`2`/`1` |
| `PRE_COUNTDOWN_INTERVAL_MS` | `1000` | 每数字停留 1 秒 |
| `TICK_INTERVAL_MS` | `100` | spec §5 FR-2 刷新频率 |
| `MS_PER_SECOND` / `SECONDS_PER_MINUTE` / `TIME_FIELD_WIDTH` | `1000` / `60` / `2` | 时间换算与格式化 |
| `BALL_SIZE` / `SAFE_GAP` / `HUD_HEIGHT` | `64` / `24` / `64` | `--ball-size` / `--safe-gap` / `--hud-height`（**仅作变量缺失时的兜底值**，尺寸唯一来源是样式表，见记录 2） |
| `INITIAL_SCORE` / `SCORE_ON_HIT` / `SCORE_ON_MISS` | `0` / `2` / `-1` | spec §5 FR-5 计分规则 |

CSS `:root` 变量核对：spec §7.2 的 8 个变量**全部落地且被实际引用**（`--color-bg` / `--color-ball` / `--color-ball-hover` / `--color-text` / `--color-panel` / `--ball-size` / `--hud-height` / `--safe-gap`），另有 T2 已说明并保留的 2 个扩展 token（`--color-on-primary` / `--shadow-panel`）。**无重复定义、无未使用变量。**

### 4. 工程规范核对

- **无内联**：`index.html` 全文无 `style="..."`、无 `onclick="..."`，样式与行为完全分离（spec §3）。
- **无第三方**：`index.html` 仅引用本地 `css/style.css` 与 `js/game.js`，无 CDN / 字体 / 图片 / 框架（spec §2）。
- **脚本位置**：`<script>` 保持在 `</body>` 前，DOM 就绪后执行，无需 `defer`（T1 约定 1 持续成立）。
- **事件绑定总数**：4 处（开始按钮、游戏区委托、重新开始按钮、window resize），无冗余绑定。

### 5. 观察项（记录留痕，非缺陷）

- **记录 1（CSS 组件级字号/间距保持字面量）**：`:root` 变量覆盖了「设计系统层」的颜色与三个核心尺寸，而按钮圆角（`999px`）、面板字号（`28px`）等**组件级一次性数值**未抽成变量。理由：spec §7.2 定义的就是这套变量集，这些值各自只出现一次，抽成变量只会增加一层间接跳转而无复用收益（YAGNI）。此处对 T2 评审中「尺寸全部收敛到变量」的表述作更精确的界定：**收敛的是复用型 token，不是全部尺寸字面量**。
- **记录 2（JS 常量与 CSS 变量的「兜底」关系）**：`BALL_SIZE` / `SAFE_GAP` / `HUD_HEIGHT` 与同名 CSS 变量数值相同，看似重复硬编码；实为 T4-R2 后的设计——`getCssPixel(name, fallback)` 优先读**样式表**，JS 常量仅在变量缺失/不可解析时兜底。因此「改 CSS 即生效」的单一来源性质成立，不构成 T7 需清理的重复硬编码。
- **记录 3（`endTime` 初值 `0` 与 `|| 0` 兜底）**：属结构化中性字面量（初始值 / 解析失败兜底），非业务魔法数字，不常量化。
- **记录 4（`<h2>` 无 `<h1>`、`<meta name="viewport">`）**：单页游戏界面无文档大纲与 SEO 需求，viewport 元信息对桌面目标无害；按 YAGNI 保留现状（沿用 T2 观察项）。
- **记录 5（状态守卫即最小权限）**：四类点击/尺寸事件全部以「先判 `PLAYING`」收敛副作用，`idle`/`countdown`/`over` 三态天然免疫，是 NFR-2/NFR-3 的结构性保证，无需额外分支。

### 6. 结论

全量复核下，代码分区清晰、命名规范、事件机制（委托 + 结构隔离 + 状态守卫）无可挑剔，CSS 无冗余、布局规范统一；仅修正一处常量命名疏漏（R3）。T1–T6 已建立的八条约定在收尾阶段全部成立且互不冲突，**通过评审**，可进入阶段 5 人工验证（G1–G15）。

---

<!-- T1–T7 全部评审报告至此完成 -->
